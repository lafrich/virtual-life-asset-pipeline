import sys;sys.argv=['x'];exec(open('runR2.py').read().split("man=[]")[0])
from rig2 import *
res={}
for vid in ['id200_transport_becak_kampung','id200_transport_bentor_roda_tiga']:
    rg=L[vid]()
    for d in DIRS:
        im,piv=rg.rgroup('m',d);PV=(110,160);cm=np.zeros((220,220),bool)
        sel=[p for p in rg.parts if p[0] in('hood','posts')];a=np.array(im)[...,3]>200
        # canopy-only mask
        r0=Rig(rg.hl,rg.hw,rg.H,[p for p in rg.parts if p[0]=='hood'],[]);r0.parts=[(n,m,f,'m') for n,m,f,g in r0.parts]
        ci,cp=r0.rgroup('m',d);ca=np.array(ci)[...,3]>200;cm[PV[1]-cp[1]:PV[1]-cp[1]+ca.shape[0],PV[0]-cp[0]:PV[0]-cp[0]+ca.shape[1]]=ca
        rs=sorted(rg.riders,key=lambda r:r[1]);spec,hx,sz,anim,ex=rs[1]
        B=ch.build_char(spec);f=ch.frame(B,anim,0,d,ex);f=f[0] if isinstance(f,tuple) else f
        sx,sy=sc.to_screen(d,hx+1.5,0,2+(sz-21));px=31 if d in('sw','nw') else 32;pos=(int(round(PV[0]+sx-px)),int(round(PV[1]+sy-100)))
        pm=np.zeros((220,220),bool);fa=np.array(f)[...,3]>0;pm[pos[1]:pos[1]+fa.shape[0],pos[0]:pos[0]+fa.shape[1]]=fa
        ov=int((pm&cm).sum());gaps=[]
        for x in range(220):
            ys=np.nonzero(pm[:,x])[0];cs=np.nonzero(cm[:,x])[0]
            if len(ys) and len(cs) and (cs<ys.min()).any():gaps.append(ys.min()-cs[cs<ys.min()].max()-1)
        res[vid[16:]+'_'+d]=dict(overlapPx=ov,minGapAboveHeadPx=int(min(gaps)) if gaps else None)
        print(vid[16:],d,res[vid[16:]+'_'+d])
json.dump(res,open('r2d-headroom.json','w'),indent=1)
