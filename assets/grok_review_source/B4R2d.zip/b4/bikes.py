from rig import *
K=1.3
def S(v):return tuple(x*K for x in v)
def bike_parts(col,cargo=None):
    t=lambda a,b,r=0.9:(lambda p:sd_capsule(p,V(*S(a)),V(*S(b)),r*1.15))
    hw=0
    P_=[('fr1',col,t((-13,0,9),(-4,0,9)),'b'),('fr2',col,t((-4,0,9),(-6,0,26)),'b'),('fr3',col,t((-13,0,9),(-6,0,25)),'b'),
        ('fr4',col,t((-4,0,9),(10,0,23)),'a'),('fr5',col,t((-6,0,24),(10,0,24.5)),'a'),('fork',col,t((13,0,9),(10,0,27)),'a'),
        ('stem','trim',t((10,0,27),(9,0,31),0.8),'a'),('bar','trim',t((8,-6,31.5),(8,6,31.5),0.8),'a'),
        ('saddle','seat',lambda p:sd_rbox(p,V(*S((-6.5,0,27.5))),(4,2.2,1.2),0.8),'b'),
        ('fend','trim',lambda p:np.maximum(sd_cyl_y(p,V(*S((13,0,9))),12.9,1.8,0.4),-sd_cyl_y(p,V(*S((13,0,9))),11.7,3,0.1)),'a'),
        ('lamp','lamp_f',lambda p:sd_sphere(p,V(*S((12.5,0,25.5))),2),'a'),
        ('pedal','trim',t((-4,-3.5,7),(-4,3.5,10),0.7),'b'),
        ('rack','trim',lambda p:sd_rbox(p,V(*S((-14,0,21))),(6.5,3.5,0.7),0.3),'b')]
    if cargo:P_+=cargo
    return P_
RAMPS['seat']=RAMPS['trim']
TUA=P(body='m',skin='medium',hair='short',hc='silver',top='shirt',tc='steel',pants='trousers',pc='walnut',shoes='shoes',sc='night')
ROTI=P(body='m',skin='deep',hair='short',hc='black',top='tee',tc='paper',pants='trousers',pc='navy',shoes='sneakers',sc='night',helmet='charcoal')
def ontel():
    return Rig(30,7,70,bike_parts('woodd'),[(17,0,11.7),(-17,0,11.7)],[(TUA,-9.5,25,'sit_type','neutral')])
def roti():
    cargo=[('box','wood',lambda p:sd_rbox(p,V(-19,0,36),(7,8,8),0.8),'b'),('boxlid','red',lambda p:sd_rbox(p,V(-19,0,44.6),(7.4,8.4,0.8),0.5),'b'),
           ('boxwin','glass',lambda p:sd_rbox(p,V(-19,0,37),(5.5,8.6,4),0.3),'b')]
    return Rig(30,9,74,bike_parts('blue',cargo),[(17,0,11.7),(-17,0,11.7)],[(ROTI,-9.5,25,'sit_type','neutral')])
