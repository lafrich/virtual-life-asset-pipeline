from rig import *
RAMPS['seat']=RAMPS['trim']
cap=lambda a,b,r:(lambda p:sd_capsule(p,V(*a),V(*b),r))
box=lambda c,h,rr=0.8:(lambda p:sd_rbox(p,V(*c),h,rr))
DRV=P(body='m',skin='deep',hair='short',hc='black',top='tee',tc='olive',pants='trousers',pc='walnut',shoes='shoes',sc='night')
PAX=P(body='f',skin='light',hair='long',hc='black',top='tee_long',tc='steel',pants='trousers',pc='navy',shoes='sneakers',sc='paper')
KUSIR=P(body='m',skin='medium',hair='short',hc='black',top='shirt',tc='batikb',pants='trousers',pc='night',shoes='shoes',sc='night')
def hood(xc,z0,w,R=17):
    return lambda p:np.maximum.reduce([sd_cyl_y(p,V(xc,0,z0),R,w,0.5),-sd_cyl_y(p,V(xc,0,z0),R-1.6,w+2,0.1),p[...,0]-(xc+8),z0-p[...,2]])
def becak():
    parts=[('seatbox','red',box((14,0,17),(8,11,6),1.5),'a'),('cushion','seatc',box((12,0,24),(5,9.5,1.4),1),'m'),
      ('back','red',box((5,0,29),(1.6,10.5,7),1),'m'),('hood','hood',hood(6,26,11.5,R=30),'m'),
      ('apron','red',box((22,0,14),(1.5,10,4),0.8),'a'),('fr','woodd',cap((6,0,12),(-22,0,13),1.3),'b'),
      ('post','woodd',cap((-16,0,13),(-17,0,33),1.2),'b'),('saddle','trim',box((-17,0,34),(3.5,2.5,1.2)),'b'),
      ('bar','trim',cap((-4,-9,40),(-4,9,40),0.9),'a'),('crank','trim',cap((-12,-3,9),(-12,3,11),0.8),'b')]
    r=Rig(36,16,74,parts,[(16,-11.5,9),(16,11.5,9),(-24,0,10)],[(PAX,11,25,'sit','smile'),(DRV,-18,32,'sit_type','neutral')]);r.layers=['b','R0','m','R1','a'];return r
def bentor():
    parts=[('seatbox','green',box((14,0,17),(8,11,6),1.5),'a'),('cushion','seatc',box((12,0,24),(5,9.5,1.4),1),'m'),
      ('back','green',box((5,0,29),(1.6,10.5,7),1),'m'),('hood','hood',hood(6,26,11.5,R=30),'m'),('apron','green',box((22,0,14),(1.5,10,4),0.8),'a'),
      ('tank','red',box((-6,0,20),(6,4.5,3.5),2),'b'),('engine','trim',box((-10,0,10),(5,4,4),1),'b'),
      ('mseat','trim',box((-17,0,23),(7,4.5,1.6),1.2),'b'),('mfend','red',box((-26,0,18),(5,4.2,2),1.5),'b'),
      ('fr','trim',cap((6,0,12),(-6,0,14),1.3),'b'),('bar','trim',cap((-2,-9,36),(-2,9,36),0.9),'a')]
    r=Rig(36,16,74,parts,[(16,-11.5,9),(16,11.5,9),(-24,0,8)],[(PAX,11,25,'sit','neutral'),(DRV,-15,23,'sit_type','neutral')]);r.layers=['b','R0','m','R1','a'];return r
def bajaj():
    prof=[(-20,7),(10,7),(16,14),(22,17),(23,24),(18,30),(13,44),(9,47),(-18,47),(-21,43)]
    parts=[('body','orange',lambda p:sd_extrude(p,prof,12,3,0.12,24),'a'),
      ('roof','trim',box((-5,0,48),(15,11.5,1.4),1),'a'),('bump','bumper',box((23,0,15),(1.4,7,1.6),0.8),'a'),
      ('wsh','glass',box((16,0,37),(1.2,8.5,6),0.6),'a'),('swin','glass',lambda p:np.minimum(sd_rbox(p,V(-2,12.6,36),(8,0.8,6),0.5),sd_rbox(p,V(-2,-12.6,36),(8,0.8,6),0.5)),'a'),
      ('door','trim',lambda p:np.minimum(sd_rbox(p,V(8,12.6,24),(4,0.7,9),0.5),sd_rbox(p,V(8,-12.6,24),(4,0.7,9),0.5)),'a'),
      ('stripe','yellow',lambda p:np.minimum(sd_rbox(p,V(-4,12.7,17),(16,0.6,1.2),0.3),sd_rbox(p,V(-4,-12.7,17),(16,0.6,1.2),0.3)),'a'),
      ('hl','lamp_f',box((23.5,0,22),(0.8,3,1.6),0.5),'a'),('tl','lamp_r',lambda p:np.minimum(sd_rbox(p,V(-21.5,9,20),(0.8,1.5,2),0.4),sd_rbox(p,V(-21.5,-9,20),(0.8,1.5,2),0.4)),'a'),
      ('fork','trim',cap((19,0,7),(18,0,18),1.4),'a')]
    r=Rig(30,15,58,parts,[(19,0,7),(-13,-11,7),(-13,11,7)])
    orig=r.rgroup
    def rg(grp,d):
        im,piv=orig(grp,d);return im,piv
    r.rgroup=rg
    return r
def bajaj_mat():
    pass
def delman():
    parts=[('wl','wood',lambda p:np.maximum(sd_cyl_y(p,V(-14,-19,16),16,1.6,0.5),-sd_cyl_y(p,V(-14,-19,16),14.2,3,0.1)),'b'),
      ('wr','wood',lambda p:np.maximum(sd_cyl_y(p,V(-14,19,16),16,1.6,0.5),-sd_cyl_y(p,V(-14,19,16),14.2,3,0.1)),'b'),
      ('spk','woodd',lambda p:np.minimum.reduce([sd_capsule(p,V(-14+16*np.cos(a),sy*19,16+16*np.sin(a)),V(-14-16*np.cos(a),sy*19,16-16*np.sin(a)),0.7) for a in np.linspace(0,np.pi,5)[:-1] for sy in(1,-1)]),'b'),
      ('axle','trim',cap((-14,-19,16),(-14,19,16),1),'b'),
      ('cart','wood',box((-12,0,26),(16,15,4),1),'b'),('bench','seatc',box((-6,0,32),(5,13,1.6),1),'b'),('backr','wood',box((-26,0,36),(2,15,7),1),'b'),
      ('roof','cream',box((-12,0,58),(18,17,1.4),1.5),'b'),('posts','woodd',lambda p:np.minimum.reduce([sd_capsule(p,V(x,y,30),V(x,y,57),0.8) for x in(-28,4) for y in(-15,15)]),'b'),
      ('shaft','woodd',lambda p:np.minimum(sd_capsule(p,V(2,-8,28),V(40,-8,30),0.9),sd_capsule(p,V(2,8,28),V(40,8,30),0.9)),'a'),
      ('hbody','horse',lambda p:sd_ellip(p,V(34,0,32),V(14,6.5,8)),'a'),
      ('hneck','horse',cap((44,0,35),(50,0,48),4.2),'a'),('hhead','horse',cap((50,0,50),(56,0,43),3),'a'),
      ('hmane','mane',cap((44,0,40),(49,0,52),1.6),'a'),('htail','mane',cap((20,0,34),(17,0,20),1.6),'a'),
      ('hlegs','horse',lambda p:np.minimum.reduce([sd_capsule(p,V(x,y,28),V(x+dx,y,2),1.8) for x,dx in((25,-1),(42,1)) for y in(-3.5,3.5)]),'a'),
      ('hhoof','trim',lambda p:np.minimum.reduce([sd_rbox(p,V(x+dx,y,1.5),(1.8,1.8,1.5),0.5) for x,dx in((25,-1),(42,1)) for y in(-3.5,3.5)]),'a'),
      ('harn','red',lambda p:sd_ellip(p,V(40,0,34),V(2,7,8.5)),'a')]
    return Rig(56,20,70,parts,[],[(KUSIR,-4,32,'sit','neutral')])
