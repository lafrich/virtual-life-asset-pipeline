# B4R2 polish: driver arms re-posed per sprite to grip the actual bar (asset-local compositing, reusing the approved
# riders_v3 pixel-arm painter read-only; the shared character generator is only *called* with its existing noarms option).
from rig import *
from rig import Rig
sys.path.insert(0,'/workspace/virtual-office-assets/street_vehicles/riders_v3/_work')
import riders_v3 as rv
class Rig2(Rig):
    """grips: {rider_idx:(gx,gy,gz,endy)} vehicle-local grip centre (+-gy) and bar end."""
    def __init__(s,base,grips,late=True):
        s.__dict__.update(base.__dict__);s.grips=grips;s.late=late
        s.layers=list(getattr(base,'layers',None) or (['b']+['R%d'%k for k in range(len(base.riders))]+['a']))
    def build(s,d,CV=220,PV=(110,160)):
        cv=Image.new('RGBA',(CV,CV))
        def put(grp):
            im,piv=s.rgroup(grp,d)
            if im is not None:cv.alpha_composite(im,(PV[0]-piv[0],PV[1]-piv[1]))
        facing=d in('se','sw');put('w');rs=sorted(s.riders,key=lambda r:r[1]);order=list(s.layers)
        if not facing:order=order[::-1]
        late=[]
        for g in order:
            if not g.startswith('R'):put(g);continue
            k=int(g[1:]);spec,hx,sz,anim,ex=rs[k];B=ch.build_char(spec)
            sx,sy=sc.to_screen(d,hx+1.5,0,2+(sz-21));px=31 if d in('sw','nw') else 32
            pos=(int(round(PV[0]+sx-px)),int(round(PV[1]+sy-100)))
            if k not in s.grips:
                im=ch.frame(B,anim,0,d,ex);im=im[0] if isinstance(im,tuple) else im;cv.alpha_composite(im,pos);continue
            im,info=ch.frame(B,anim,0,d,ex,noarms=True)
            shs=[rv.shoulder(info[a],pos) for a in('arm_near','arm_far')]
            rmp=rv.arm_ramps(info['arm_near']);rmp=(rmp[0],rmp[1],spec['top'] in('hoodie','tee_long','shirt_l'))
            gx,gy,gz,ey=s.grips[k]
            tg=[rv.scr(d,(gx,sg*gy,gz),PV) for sg in(1,-1)];en=[rv.scr(d,(gx,sg*ey,gz),PV) for sg in(1,-1)]
            bd=[]
            for t,e in zip(tg,en):
                v=(e[0]-t[0],e[1]-t[1]);n=max(1e-6,(v[0]**2+v[1]**2)**.5);bd.append((v[0]/n,v[1]/n))
            os_=sorted(range(2),key=lambda i:shs[i][0]);ot=sorted(range(2),key=lambda i:tg[i][0])
            arms=[(shs[os_[i]],tg[ot[i]],bd[ot[i]]) for i in range(2)]
            if facing:
                far,near=sorted(arms,key=lambda t:t[1][1])
                rv.draw_arm(cv,far[0],far[1],rmp,far[2],arm_only=True);cv.alpha_composite(im,pos)
                L_=[(far,rmp,'hand'),(near,rmp,'all')]
                if s.late:late+=L_
                else:
                    for a,rm,mo in L_:rv.draw_arm(cv,a[0],a[1],rm,a[2],hand_only=(mo=='hand'))
            else:
                for a in arms:rv.draw_arm(cv,a[0],a[1],rmp,a[2])
                cv.alpha_composite(im,pos)
        for a,rmp,mode in late:rv.draw_arm(cv,a[0],a[1],rmp,a[2],hand_only=(mode=='hand'))
        return cv,PV
