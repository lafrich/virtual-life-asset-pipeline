import sys,json
from rig2 import *
import bikes,three
from three import cap,box
def scaled(r,K):
    r.parts=[(n,m,(lambda f:(lambda p:K*f(p/K)))(f),g) for n,m,f,g in r.parts]
    r.wheels=[(x*K,y*K,R*K) for x,y,R in r.wheels];r.hl*=K;r.hw*=K;r.H*=K;return r
def bajaj2():
    prof=[(-25,13),(15,13),(21,14),(26,17),(27,23),(23,28),(17,40),(13,42),(-25,42)]
    sides=lambda c,h,rr=0.4:(lambda p:np.minimum(sd_rbox(p,V(c[0],c[1],c[2]),h,rr),sd_rbox(p,V(c[0],-c[1],c[2]),h,rr)))
    hw=12.5
    parts=[('body','orange',lambda p:sd_extrude(p,prof,hw,3,0.06,20),'a'),
      ('skirt','trim',box((0,0,13.5),(24,hw-0.6,1.2),0.6),'a'),
      ('roof','trim',box((-5,0,43.5),(20.5,hw+0.4,1.0),0.8),'a'),
      ('cab','glassd',sides((5,hw+0.15,27),(8,0.5,10),1.2),'a'),
      ('rwin','glass',sides((-14,hw+0.15,33),(7,0.5,4.5),0.8),'a'),
      ('wsh','glass',lambda p:sd_rbox(p,V(19.5,0,34),(0.9,hw-2,5),0.5),'a'),
      ('bwin','glass',box((-25.3,0,33),(0.6,hw-3,4),0.5),'a'),
      ('stripe','yellow',sides((-6,hw+0.2,16),(19,0.5,1.1),0.3),'a'),
      ('nose','yellow',box((26.6,0,21),(0.8,6,1),0.4),'a'),
      ('hl','lamp_f',box((27.2,0,25),(0.8,2.6,2),0.6),'a'),
      ('tl','lamp_r',sides((-25.5,9.5,20),(0.7,1.4,2.4),0.4),'a'),
      ('bump','bumper',box((-26,0,14),(1.2,hw-1,1.4),0.6),'a'),
      ('mirror','trim',sides((18,hw+1.6,36),(0.8,1.2,1.4),0.4),'a'),
      ('fork','trim',cap((22,0,8),(21,0,17),1.6),'a')]
    return scaled(Rig(34,15,52,parts,[(22,0,8),(-14,-hw+1.5,8),(-14,hw-1.5,8)]),1.12)
def canopy(xc=13,zc=84,R=20,w=12,xf=22,xb=1):
    # arched canopy shell fully ABOVE the passenger head (inner top z~76), open below z=zc
    sh=lambda p:np.maximum.reduce([sd_cyl_y(p,V(xc,0,zc),R,w,0.5),-sd_cyl_y(p,V(xc,0,zc),R-1.4,w+2,0.1),p[...,0]-xf,zc-p[...,2],xb-p[...,0]])
    posts=lambda p:np.minimum.reduce([sd_capsule(p,V(x,y,22),V(x,y,z),0.7) for x,z in((xb+1,zc+np.sqrt(R*R-(xb+1-xc)**2)-1),(xf-0.5,zc+np.sqrt(R*R-(xf-xc)**2)-1)) for y in(-w+0.8,w-0.8)])
    return [('hood','hood',sh,'m'),('posts','trim',posts,'m')]
def becak2():
    r=three.becak();r.parts=[p for p in r.parts if p[0]!='hood']+canopy()
    return Rig2(r,{0:(-4,7.5,40,9.3)},late=False)
def bentor2():
    # R2b geometry fix: one centred motorbike rear (y=0) bolted to the cab underframe; hood covers only the cab
    parts=[('seatbox','green',box((14,0,17),(8,11,6),1.5),'a'),('cushion','seatc',box((12,0,24),(5,9.5,1.4),1),'m'),
      ('back','green',box((5,0,29),(1.6,10.5,7),1),'m'),('apron','green',box((22,0,14),(1.5,10,4),0.8),'a'),*canopy(),
      ('chassis','trim',lambda p:np.minimum(sd_capsule(p,V(8,0,10),V(-22,0,10),1.4),sd_rbox(p,V(5,0,10.5),(3,9,1.2),0.5)),'b'),
      ('neck','trim',cap((2,0,12),(-1,0,31),1.3),'b'),
      ('tank','red',lambda p:sd_ellip(p,V(-6,0,22),V(5.5,3.6,3)),'b'),
      ('engine','trim',box((-8,0,12),(4.5,3.2,3.5),1.2),'b'),('exh','rim',cap((-6,3.8,9),(-24,3.8,12),0.9),'b'),
      ('mseat','seat',box((-15,0,24),(6.5,3.6,1.4),1.2),'b'),('cover','red',box((-16,0,19),(6,3.4,3.5),1.6),'b'),
      ('mfend','red',lambda p:np.maximum(sd_cyl_y(p,V(-24,0,8),10,3.4,0.5),np.maximum(-sd_cyl_y(p,V(-24,0,8),8.9,4,0.1),8-p[...,2])),'b'),
      ('tl','lamp_r',box((-30,0,15),(0.7,2,1),0.4),'b'),
      ('bar','trim',cap((-1,-7.5,33),(-1,7.5,33),0.8),'a')]
    r=Rig(36,16,74,parts,[(16,-11.5,9),(16,11.5,9),(-24,0,8)],[(three.PAX,11,25,'sit','neutral'),(three.DRV,-15,24,'sit_type','neutral')]);r.layers=['b','R0','m','R1','a']
    return Rig2(r,{0:(-1,6.2,33,7.6)},late=False)
def delman2():
    r=three.delman()
    r.parts+=[('rein','trim',lambda p:np.minimum(sd_capsule(p,V(8,-3.2,37),V(50,-3,45),0.45),sd_capsule(p,V(8,3.2,37),V(50,3,45),0.45)),'a')]
    return Rig2(r,{0:(6,3.2,37,3.4)})
K=bikes.K
L={'id200_transport_sepeda_ontel_tua':lambda:Rig2(bikes.ontel(),{0:(10.4*K,5.2*K,31.5*K,6.2*K)}),
   'id200_transport_sepeda_tukang_roti':lambda:Rig2(bikes.roti(),{0:(10.4*K,5.2*K,31.5*K,6.2*K)}),
   'id200_transport_becak_kampung':becak2,
   'id200_transport_bentor_roda_tiga':bentor2,
   'id200_transport_bajaj_oranye':bajaj2,'id200_transport_delman_andong':delman2}
man=[]
for vid in sys.argv[1:] or L:man+=place(L[vid](),vid,'outR2')
if not sys.argv[1:]:json.dump(man,open('b4r2-manifest.json','w'),indent=1)
for m in man:print(m['id'][16:],m['dir'],m['size'],m['lostOpaquePx'])
