# City props C1: detailed isometric remakes of runtime builtins, rendered with the approved SDF vehicle generator.
import sys,os,json,hashlib
sys.path.insert(0,'/workspace/semesta-vehicles-r1/b4')
from rig import *
cap=lambda a,b,r:(lambda p:sd_capsule(p,V(*a),V(*b),r))
box=lambda c,h,rr=0.6:(lambda p:sd_rbox(p,V(*c),h,rr))
U=lambda *fs:(lambda p:np.minimum.reduce([f(p) for f in fs]))
RAMPS.update({'slat':R5('#C08A55','#A06E3E','#6E4524'),'iron':R5('#3E5A4A','#2C4237','#18251E'),
  'ironl':R5('#5A7A66','#3E5A4A','#22332A'),'binG':R5('#3F9A5A','#2E7A45','#1A4A2A'),'binY':R5('#E8C23A','#C99D22','#8A6810'),
  'conc':R5('#BDB8AE','#9E998F','#6E6A62'),'glow':R5('#FFF4C8','#FFE59A','#E8B850'),'gold':R5('#E0B84A','#B8902E','#7A5C18')})
def bench():
    P=[]
    for x in(-22,22):  # cast-iron end frames with armrests
        P+=[('leg%d'%x,'iron',U(cap((x,-6,1),(x,-5,12),1.1),cap((x,6,1),(x,4,12),1.1),cap((x,6,12),(x,8,30),1.0),cap((x,-6,13),(x,6,13),1.0),
             cap((x,-6,20),(x,5,20),0.9),cap((x,-6,20),(x,-6,13),0.9)),'w')]
    for i,y in enumerate((-5,-2,1,4)):P+=[('s%d'%i,'slat',box((0,y,13.8),(25,1.25,0.7),0.4),'w')]
    for i,z in enumerate((21,25,29)):P+=[('b%d'%i,'slat',box((0,7.2+0.15*(z-21),z),(25,0.7,1.4),0.4),'w')]
    return Rig(30,10,34,P,[])
def table():
    P=[('top','slat',U(*[box((0,y,22),(22,2.6,0.9),0.4) for y in(-8,-2.6,2.8,8.2)]),'w')]
    for y in(-19,19):P+=[('seat%d'%y,'slat',U(box((0,y-1.5,13),(22,1.4,0.7),0.3),box((0,y+1.5,13),(22,1.4,0.7),0.3)),'w')]
    for x in(-15,15):P+=[('fr%d'%x,'iron',U(cap((x,-17,0),(x,0,21),1.1),cap((x,17,0),(x,0,21),1.1),cap((x,-21,12),(x,21,12),1.0)),'w')]
    return Rig(28,24,26,P,[])
def lamp():
    P=[('plinth','conc',box((0,0,2),(4,4,2),0.6),'w'),('base','iron',U(cap((0,0,4),(0,0,12),3.2),cap((0,0,4),(0,0,5),4)),'w'),
       ('ring1','gold',cap((0,0,13),(0,0,14),2.6),'w'),('pole','iron',cap((0,0,14),(0,0,108),1.6),'w'),
       ('ring2','gold',cap((0,0,95),(0,0,96),2.3),'w'),('arm','iron',U(cap((0,0,108),(0,0,112),2.6),cap((-3,0,100),(0,0,109),0.7),cap((3,0,100),(0,0,109),0.7)),'w'),
       ('lanf','iron',U(*[cap((sx*4.2,sy*4.2,112),(sx*5.2,sy*5.2,124),0.6) for sx in(1,-1) for sy in(1,-1)]),'w'),
       ('glass','glow',lambda p:sd_rbox(p,V(0,0,118),(3.9,3.9,5.6),0.8),'w'),
       ('roof','iron',U(box((0,0,125.5),(6.4,6.4,0.9),0.5),cap((0,0,126),(0,0,130),2.6)),'w'),('fin','gold',cap((0,0,130),(0,0,133),0.9),'w')]
    return Rig(8,8,136,P,[])
def trashbin():
    P=[('body','binG',U(lambda p:sd_cyl_z(p,V(0,0,0),9.5,26) if 'sd_cyl_z' in globals() else sd_rbox(p,V(0,0,13),(9,9,12.5),4)),'w'),
       ('ribs','iron',U(*[box((0,0,z),(9.8,9.8,0.7),4.2) for z in(4,22)]),'w'),('lbl','binY',box((0,0,13),(9.7,9.7,2.2),4.1),'w'),
       ('lid','iron',U(box((0,0,26.5),(10.2,10.2,1.2),4.5),box((0,0,28.8),(6,6,1.3),2.5)),'w'),('slot','glassd',box((0,0,29.6),(3,7,0.6),0.3),'w')]
    return Rig(12,12,32,P,[])
SRC='/workspace/semesta-props-next-b3/'
SM={(r['catalogId'],r['direction']):r for r in json.load(open('src-builtin-manifest.json'))}
def place(rig,cid,mode):
    """mode 'contract': exact original size+pivot; if the iso footprint's lower half cannot fit below the pivot the
    model is lifted (groundOffsetPx = how far the footprint centre sits above the anchor). mode 'proposal': pivot stays
    at the true footprint centre and the canvas is extended downward only (needs a BUILTIN_DIMENSIONS change)."""
    res=[];os.makedirs('out_'+mode,exist_ok=True)
    for d in DIRS:
        o=SM[(cid,d)];W,H=o['size'];px,py=o['pivot']
        im,PV=rig.build(d);a=np.array(im)[...,3];ys,xs=np.nonzero(a);bot=ys.max()-PV[1];top=PV[1]-ys.min()
        lift=max(0,py+bot-(H-1)) if mode=='contract' else 0
        H2=H if mode=='contract' else max(H,py+bot+2)
        cv=Image.new('RGBA',(W,H2));cv.paste(im,(px-PV[0],py-PV[1]-lift),im)
        lost=int((a>0).sum()-(np.array(cv)[...,3]>0).sum())
        fn=f'out_{mode}/{cid}_{d}.png';cv.save(fn)
        res.append(dict(catalogId=cid,dir=d,mode=mode,file=fn,size=[int(W),int(H2)],pivot=[px,py],originalSize=[W,H],footprint=o['footprint'],
            groundOffsetPx=int(lift),headroomTopPx=int(py-lift-top),lostOpaquePx=lost,sha256=hashlib.sha256(open(fn,'rb').read()).hexdigest(),
            originalFile=SRC+o['file'],originalSha256=o['sha256'],status='C1 proposed, NOT LIVE'))
    return res
def scaled(r,K):
    r.parts=[(n,m,(lambda f:(lambda p:K*f(p/K)))(f),g) for n,m,f,g in r.parts];r.hl*=K;r.hw*=K;r.H*=K;return r
if __name__=='__main__':
    L={'park-bench':bench,'park-table':table,'park-lamp':lambda:scaled(lamp(),0.97),'trash-bin':trashbin};man=[]
    for k in sys.argv[1:] or L:man+=place(L[k](),k,'contract')+place(L[k](),k,'proposal')
    json.dump(man,open('c1-manifest.json','w'),indent=1)
    for m in man:print(m['catalogId'],m['dir'],m['mode'],m['size'],'lift',m['groundOffsetPx'],'top',m['headroomTopPx'],'lost',m['lostOpaquePx'])
