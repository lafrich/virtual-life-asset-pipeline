import sys,os,json,hashlib
sys.path.insert(0,'.');sys.path.insert(0,'/workspace/virtual-office-assets/street_vehicles/_work')
import numpy as np
from PIL import Image
from sdf import *
from grade import grade
from cars import common_ramps
import chars as ch, scoot as sc
ch.nv.CL.update({'tan':'#B98B5A','olive':'#6E7B3A','kurir':'#D9452B','batikb':'#8A5A3A'})
P=lambda **k:k
DIRS=['se','sw','ne','nw']
def R5(*h):return ramp5(*[grade(x) for x in h])
RAMPS=common_ramps(False)
RAMPS.update({'wood':R5('#D9A066','#B07A45','#7E522C'),'woodd':R5('#9A6A3E','#7A4F2C','#55361E'),'hood':R5('#5A6B8C','#3E4C6B','#2A3550'),
 'red':R5('#F06A5A','#D94B4B','#A8323A'),'orange':R5('#FFA04A','#F07C22','#C25A14'),'blue':R5('#6FA3E8','#3F7FE0','#2C5BA8'),
 'horse':R5('#B57A4A','#8E5A33','#5E3A20'),'mane':R5('#4A3426','#33231A','#211611'),'cream':R5('#F4EBD6','#E0D3B5','#B8A988'),
 'green':R5('#5CC46F','#3FA555','#2A7A3C'),'yellow':R5('#FFE07A','#F2C14E','#C9962A'),'glassd':RAMPS['glass'],'seatc':R5('#C24A3A','#9A3328','#6A2219')})
def wheelmat(pl,nl,wheels,names):
    m=np.array(['tyre']*len(pl),object)
    for (wx,wy,R) in wheels:
        dx,dz=pl[:,0]-wx,pl[:,2]-R;rad=np.sqrt(dx**2+dz**2);near=np.abs(pl[:,1]-wy)<3;side=np.abs(nl[:,1])>.55
        inner=near&side&(rad<R*0.8)
        m=np.where(inner,'void',m)
        sp=np.cos(6*np.arctan2(dz,dx))>0.8
        m=np.where(inner&(sp|(rad<R*0.18)),'rim',m)
    return m
class Rig:
    """parts: (name,mat,fn,group) group 'w' wheels, 'b' behind-rider (x<split), 'a' ahead; riders: (spec,hip_x,seat_z,anim,expr)"""
    def __init__(s,hl,hw,H,parts,wheels,riders=(),split=0.0):
        s.hl,s.hw,s.H,s.parts,s.wheels,s.riders,s.split=hl,hw,H,parts,wheels,riders,split
    def rgroup(s,grp,d):
        m=Model();mats={}
        sel=[p for p in s.parts if p[3]==grp]
        if grp=='w':sel+= [('wheel','tyre',(lambda wx,wy,R:(lambda p:sd_cyl_y(p,V(wx,wy,R),R,1.2 if R>7.5 and abs(wy)<1 else 2.2,0.8)))(wx,wy,R),'w') for wx,wy,R in s.wheels]
        if not sel:return None,None
        for n,mt,fn,g in sel:m.add(n,fn);mats[n]=mt
        def matfn(pl,nl,nw,names,lam,info):
            N=len(pl);mm=np.array(['trim']*N,object)
            for n,mt in mats.items():mm[names==n]=mt
            w=names=='wheel'
            if w.any():wm=wheelmat(pl,nl,s.wheels,names);mm[w]=wm[w]
            return mm,np.zeros(N,int)
        sh=(s.hl-2,s.hw,4) if grp=='w' else None
        r=dict(RAMPS);r['void']=[(0,0,0)]*5
        img,piv=render(m,d,s.hl+4,s.hw+2,s.H,shadow_rr=sh,matfn=matfn,ramps=r,shadow_extra=1.0)
        a=np.array(img);v=(a[...,0]==0)&(a[...,1]==0)&(a[...,2]==0)&(a[...,3]==255);a[v]=0
        return Image.fromarray(a),piv
    def build(s,d,CV=220,PV=(110,160)):
        cv=Image.new('RGBA',(CV,CV))
        def put(grp):
            im,piv=s.rgroup(grp,d)
            if im is not None:cv.alpha_composite(im,(PV[0]-piv[0],PV[1]-piv[1]))
        facing=d in('se','sw')
        put('w')
        rs=sorted(s.riders,key=lambda r:r[1])
        order=getattr(s,'layers',None) or (['b']+['R%d'%i for i in range(len(rs))]+['a'])
        if not facing:order=order[::-1]
        for g in order:
            if not g.startswith('R'):put(g);continue
            for spec,hx,sz,anim,ex in [rs[int(g[1:])]]:
                B=ch.build_char(spec);im=ch.frame(B,anim,0,d,ex);im=im[0] if isinstance(im,tuple) else im
                sx,sy=sc.to_screen(d,hx+1.5,0,2+(sz-21));px=31 if d in('sw','nw') else 32
                cv.alpha_composite(im,(int(round(PV[0]+sx-px)),int(round(PV[1]+sy-100))))
        return cv,PV
def place(rig,vid,outdir='out'):
    cov={x['id']:x for x in json.load(open('/workspace/semesta-gallery-public-b2/data/coverage-index-public-b2.json'))}
    PR='/workspace/semesta-gallery-originals-public/assets/street_buildings/props/';res=[]
    for d in DIRS:
        im,PV=rig.build(d);o=[x for x in cov[vid]['originals'] if x['direction']==d][0];W,H=o['catalogSize'];px,py=o['pivot']
        cv=Image.new('RGBA',(W,H));cv.paste(im,(px-PV[0],py-PV[1]),im)
        lost=int((np.array(im)[...,3]>0).sum()-(np.array(cv)[...,3]>0).sum())
        fn=f'{outdir}/{vid}_{d}.png';cv.save(fn);src=PR+f'{vid}_{d}.png'
        res.append(dict(id=vid,dir=d,file='b4/'+fn,size=[W,H],pivot=[px,py],lostOpaquePx=lost,sha256=hashlib.sha256(open(fn,'rb').read()).hexdigest(),originalFile=src,originalSha256=hashlib.sha256(open(src,'rb').read()).hexdigest()))
    return res
