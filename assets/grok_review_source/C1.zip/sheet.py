from PIL import Image,ImageDraw
ks=['park-bench','park-table','park-lamp','trash-bin'];S=4
rows=[]
for k in ks:
  for src in ['/workspace/semesta-props-next-b3/originals','out_contract','out_proposal']:
    rows.append([Image.open(f'{src}/{k}_{d}.png') for d in ['se','sw','ne','nw']])
CW=max(i.width for r in rows for i in r)*S+12;rh=[max(i.height for i in r)*S+16 for r in rows]
W=Image.new('RGBA',(4*CW+110,sum(rh)),(200,200,200,255));D=ImageDraw.Draw(W);y=0
for n,(r,h) in enumerate(zip(rows,rh)):
  D.text((2,y+4),ks[n//3]+'\n'+['ORIGINAL','C1 exact canvas','C1 extended canvas'][n%3],fill=(0,0,0,255))
  for j,im in enumerate(r):
    x=110+j*CW;D.rectangle([x-1,y+11,x+im.width*S,y+12+im.height*S],outline=(120,120,120,255));W.alpha_composite(im.resize((im.width*S,im.height*S),0),(x,y+12))
  y+=h
W.save('CITYPROPS-C1-BEFORE-AFTER-4X.png');print(W.size)
