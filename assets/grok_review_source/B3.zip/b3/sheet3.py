import sys
from PIL import Image,ImageDraw
P='/workspace/semesta-gallery-originals-public/assets/street_buildings/props/'
ids=sys.argv[2:];S=2;cw,ch=130*S+10,150*S+20
W=Image.new('RGBA',(4*cw,len(ids)*2*ch+10),(220,222,225,255));D=ImageDraw.Draw(W);r=0
for k in ids:
  for lab,base in [('BEFORE live',P),('AFTER proposed NOT LIVE','out/')]:
    for j,d in enumerate(['se','sw','ne','nw']):
      im=Image.open(f'{base}{k}_{d}.png').convert('RGBA');im=im.resize((im.width*S,im.height*S),0)
      x,y=j*cw+4,r*ch+16;W.alpha_composite(im,(x,y));D.text((x,y-13),f'{lab}: {k[22:]} {d}',fill=(0,0,0,255))
    r+=1
W.save(sys.argv[1])
