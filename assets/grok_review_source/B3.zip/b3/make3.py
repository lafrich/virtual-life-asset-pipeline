import sys,os,json,hashlib;sys.path.insert(0,'.')
import riders_v3 as R, chars as ch
from PIL import Image
from multiprocessing import Pool
ch.nv.CL.update({'kurir':'#D9452B','tan':'#B98B5A','olive':'#6E7B3A','pink':'#E58FA8'})
P=R.P
WARGA=P(body='m',skin='deep',hair='short',hc='black',top='tee',tc='olive',pants='trousers',pc='walnut',shoes='sneakers',sc='night',helmet='grey')
AYAH=P(body='m',skin='medium',hair='short',hc='black',top='shirt',tc='steel',pants='trousers',pc='navy',shoes='shoes',sc='night',helmet='night')
IBU=P(body='f',skin='light',hair='long',hc='black',top='tee_long',tc='pink',pants='trousers',pc='charcoal',shoes='sneakers',sc='paper',helmet='paper') 
KURIR=P(body='m',skin='medium',hair='short',hc='black',top='hoodie',tc='kurir',inner='night',pants='trousers',pc='night',shoes='shoes',sc='night',helmet='charcoal')
PAXB=P(body='m',skin='medium',hair='short',hc='black',top='shirt',tc='paper',pants='trousers',pc='charcoal',shoes='shoes',sc='night',helmet='gojek')
R.RIDERS.update({
 'id200_transport_motor_bebek_warga':(dict(paint=R.RED,paint2=R.BLACK),[(WARGA,-6,'sit_type','neutral')],1.3,'warga rider, red bebek'),
 'id200_transport_motor_matik_keluarga':(dict(paint=R.SILVER,paint2=R.BLACK,long=True),[(IBU,-16,'sit','smile'),(AYAH,-4,'sit_type','neutral')],1.55,'father driving, mother pillion (long seat)'),
 'id200_transport_motor_ojol_box_makanan':(dict(paint=R.BLACK,paint2=R.RED,bag=True),[(R.OJ_G,-6,'sit_type','neutral')],1.3,'ojol driver + food box'),
 'id200_transport_motor_ojol_dengan_penumpang':(dict(paint=R.BLACK,paint2=R.RED),[(PAXB,-15,'sit','neutral'),(R.OJ_G,-6,'sit_type','neutral')],1.3,'ojol driver + office passenger'),
 'id200_transport_motor_kurir_barang':(dict(paint=R.WHITE,paint2=R.BLACK,bag=True),[(KURIR,-6,'sit_type','neutral')],1.3,'courier, red jacket + rear box'),
})
IDS=[k for k in R.RIDERS if k.startswith('id200')]
cov={x['id']:x for x in json.load(open('/workspace/semesta-gallery-public-b2/data/coverage-index-public-b2.json'))}
PR='/workspace/semesta-gallery-originals-public/assets/street_buildings/props/'
def job(vid):
    _,fr=R.build(vid);res=[]
    for d in R.DIRS:
        im=fr[d,0];o=[x for x in cov[vid]['originals'] if x['direction']==d][0];W,H=o['catalogSize'];px,py=o['pivot']
        cv=Image.new('RGBA',(W,H));cv.paste(im,(px-R.PV[0],py-R.PV[1]),im)
        lost=sum(1 for a in im.getchannel('A').getdata() if a)-sum(1 for a in cv.getchannel('A').getdata() if a)
        fn=f'out/{vid}_{d}.png';cv.save(fn);src=PR+f'{vid}_{d}.png'
        res.append(dict(id=vid,dir=d,file='b3/'+fn,size=[W,H],pivot=[px,py],lostOpaquePx=lost,note=R.RIDERS[vid][3],sha256=hashlib.sha256(open(fn,'rb').read()).hexdigest(),originalFile=src,originalSha256=hashlib.sha256(open(src,'rb').read()).hexdigest()))
    return res
if __name__=='__main__':
    os.makedirs('out',exist_ok=True)
    with Pool(5) as p: allr=sum(p.map(job,IDS),[])
    json.dump(allr,open('b3-manifest.json','w'),indent=1)
    for r in allr:print(r['id'][16:],r['dir'],r['size'],r['lostOpaquePx'])
