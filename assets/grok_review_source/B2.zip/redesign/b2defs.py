import numpy as np
from cars import *
from car_defs import Van, Bus, text_rows, glyph_hits
from sdf import ramp5,hexrgb,sd_rbox,sd_sphere,sd_ellip,V
from grade import grade
T=32
def R5(*h): return ramp5(*[grade(x) for x in h])
class CabOver(Car):
    """Cab-over pickup/truck built on the approved Van template (same SDF/material system)."""
    def __init__(s,name,L,W,cabL,cabH,paint,bed,wallH=10,bedZ=24,R=10.5,cargo=None,wheel_x=None):
        hl=L*T/2; xc=hl-cabL
        body=[(-hl,4),(hl,4),(hl+.4,14),(hl-.6,30),(hl-3.5,36),(hl-12,cabH-4),(hl-16,cabH),(xc,cabH),(xc-1,bedZ),(-hl,bedZ)]
        wx=wheel_x or [hl-cabL*0.55,-hl+20]
        hw=W*T/2
        def extra(c):
            out=[]
            if bed=='bed':
                y0=hw-1.2
                out+=[('wall',lambda p: np.minimum.reduce([sd_rbox(p,V((xc-2-hl)/2,y0,bedZ+wallH/2),((xc-2+hl)/2,1.2,wallH/2),.4),
                      sd_rbox(p,V((xc-2-hl)/2,-y0,bedZ+wallH/2),((xc-2+hl)/2,1.2,wallH/2),.4),
                      sd_rbox(p,V(-hl+1.2,0,bedZ+wallH/2),(1.2,hw,wallH/2),.4),
                      sd_rbox(p,V(xc-3,0,bedZ+wallH/2+3),(1.2,hw,wallH/2+3),.4)]))]
            if cargo: out+=cargo(hl,hw,xc,bedZ)
            return out
        super().__init__(name,L,W,body=body,cabin=[(0,10),(1,10),(1,11)],cab_hw=4,wheel_x=wx,R=R,paint=paint,rr=3,mirrors=False,extra=extra)
        s.xc=xc;s.cabH=cabH;s.bedZ=bedZ;s.height=max(cabH,bedZ+wallH+26)+6
        s.model.add('mirror',lambda p: np.minimum(sd_rbox(p,V(hl-8,hw+1.2,cabH-24),(1.2,1.4,3),.5),sd_rbox(p,V(hl-8,-hw-1.2,cabH-24),(1.2,1.4,3),.5)))
        s.ramps['wallc']=R5('#D9D3C7','#B8B2A6','#8E897F')
    def matfn(s,pl,nl,nw,names,lam,info):
        x,y,z=pl[:,0],pl[:,1],pl[:,2];nx,ny,nz=nl[:,0],nl[:,1],nl[:,2]
        N=len(pl);m=np.array(['paint']*N,object);toff=np.zeros(N,int);isb=names=='body'
        side=np.abs(ny)>.55;fr=nx>.35;rear=nx<-.5;hw=s.hw;hl=s.hl;H=s.cabH
        m[isb&fr&(z>H*0.5)&(z<H-4)&(np.abs(y)<hw-2.2)&(nz<.9)]='glass'
        m[isb&side&(x>s.xc+5)&(x<hl-6-(z-H*0.5)*0.27)&(z>H*0.53)&(z<H-6)]='glass'
        m[isb&fr&(z>18)&(z<25)&(np.abs(y)>hw-8)]='lamp_f'
        m[isb&fr&(z>12)&(z<18)&(np.abs(y)<hw-8)]='trim'
        m[isb&rear&(z>12)&(z<20)&(np.abs(y)>hw-6)]='lamp_r'
        m[isb&(np.abs(x)>hl-6)&(z<11.5)&(z>3)]='bumper'
        m[isb&(np.abs(nx)>.45)&(z>6.5)&(z<10.5)&(np.abs(y)<5)]='plate'
        m[isb&(x<s.xc)&(z<s.bedZ+.5)]='trim'
        m[isb&(z<8.5)&side]='trim'
        toff[isb&side&(np.abs(x-(s.xc+(hl-s.xc)*0.45))<.6)&(z>10)&(z<H-2)&(m=='paint')]+=1
        w=names=='wheel';wm=wheel_mat(pl,nl,s.wheels,s.R);m[w]=wm[w]
        m[names=='mirror']='trim';m[names=='wall']='wallc'
        for nm in ('crate','veg','galon','galon_cap','sand','brick','bin','bin_lid','rod'): m[names==nm]=nm
        return m,toff
def pikap_sayur():
    def cargo(hl,hw,xc,bz):
        out=[]
        for i,cx in enumerate(np.linspace(-hl+9,xc-11,3)):
            for sy in (1,-1):
                out.append(('crate',(lambda cx,sy:lambda p: sd_rbox(p,V(cx,sy*hw*0.45,bz+6),(7,hw*0.42,6),.6))(cx,sy)))
                out.append(('veg',(lambda cx,sy:lambda p: sd_ellip(p,V(cx,sy*hw*0.45,bz+13),(6.5,hw*0.38,3.5)))(cx,sy)))
        return out
    c=CabOver('pikap_sayur',3.6,1.3,30,72,['#F2F4F6','#D7DCE1','#AEB6BF'],'bed',cargo=cargo)
    c.ramps['paint']=[hexrgb(h) for h in ['#FFFFFF','#EEF0F2','#D7DCE1','#AEB6BF','#85909C']]
    c.ramps['crate']=R5('#E2B36A','#C8914A','#9A6A33');c.ramps['veg']=R5('#7FD36B','#4FB04C','#2F7D35');return c
def pikap_galon():
    def cargo(hl,hw,xc,bz):
        out=[]
        for cx in np.linspace(-hl+7,xc-9,4):
            for sy in (1,0,-1):
                out.append(('galon',(lambda cx,sy:lambda p: sd_rbox(p,V(cx,sy*hw*0.6,bz+8),(4.2,4.2,8),3.5))(cx,sy)))
                out.append(('galon_cap',(lambda cx,sy:lambda p: sd_rbox(p,V(cx,sy*hw*0.6,bz+17),(1.6,1.6,1.3),.5))(cx,sy)))
        return out
    c=CabOver('pikap_galon',3.6,1.3,30,72,['#3F7FE0','#2C6BD8','#2457B8'],'bed',cargo=cargo)
    c.ramps['galon']=[hexrgb(h) for h in ['#DFF3FF','#A9DCF7','#7CC3EC','#4F9FD3','#2F77AD']];c.ramps['galon_cap']=R5('#4F8DE8','#2C6BD8','#1F4FA8');return c
def truk_pasir():
    def cargo(hl,hw,xc,bz):
        return [('sand',lambda p: sd_ellip(p,V((xc-hl)/2-2,0,bz+12),((xc+hl)/2-6,hw-4,9)))]
    c=CabOver('truk_pasir',4.1,1.5,32,76,['#FFB43A','#F29A1F','#C77614'],'bed',wallH=11,bedZ=27,R=12,cargo=cargo)
    c.ramps['wallc']=R5('#E8C07A','#C99A52','#9A7139');c.ramps['sand']=R5('#E6CB94','#CFAE6E','#A88650');return c
def truk_material():
    def cargo(hl,hw,xc,bz):
        out=[('brick',lambda p: sd_rbox(p,V(-hl+18,0,bz+7),(14,hw-5,7),.5)),
             ('crate',lambda p: sd_rbox(p,V(xc-22,hw*0.35,bz+6),(8,hw*0.45,6),.5))]
        for k in range(3):out.append(('rod',(lambda k:lambda p: sd_rbox(p,V((xc-hl)/2-2,-hw*0.45+k*3,bz+16+k*0.3),((xc+hl)/2-4,.9,.9),.3))(k)))
        return out
    c=CabOver('truk_material',4.1,1.5,32,76,['#E9EEF3','#C9D2DB','#9AA6B3'],'bed',wallH=11,bedZ=27,R=12,cargo=cargo)
    c.ramps['wallc']=R5('#E87A3A','#D0612A','#A2471D');c.ramps['brick']=R5('#E07A5A','#C15A3E','#8F3F2C')
    c.ramps['crate']=R5('#E2B36A','#C8914A','#9A6A33');c.ramps['rod']=R5('#9AA3AD','#6E7782','#4A525C');return c
def angkut_sampah():
    def cargo(hl,hw,xc,bz):
        return [('bin',lambda p: sd_rbox(p,V((xc-hl)/2-1,0,bz+13),((xc+hl)/2-3,hw-1,13),2.5)),
                ('bin_lid',lambda p: sd_rbox(p,V((xc-hl)/2-1,0,bz+26.5),((xc+hl)/2-4,hw-2,1.2),.6))]
    c=CabOver('angkut_sampah',3.9,1.4,30,72,['#3FB867','#2E9E52','#227A3E'],'none',bedZ=26,R=12,cargo=cargo)
    c.ramps['bin']=R5('#F0B23A','#D9952A','#A86F1E');c.ramps['bin_lid']=R5('#4E5A66','#3B4550','#2A323B');c.height=84;return c
class Elf(Van):
    def __init__(s,L,paint,stripe,H=86):
        hl=L*T/2
        Car.__init__(s,'elf',L,1.25,body=[(-hl,4),(hl,4),(hl+.4,14),(hl-.6,30),(hl-3.5,36),(hl-14,H-4),(hl-18,H),(-hl+2,H),(-hl,H-4),(-hl-.4,10)],
          cabin=[(0,40),(1,40),(1,41)],cab_hw=4,wheel_x=[hl-22,-hl+28],R=12,paint=paint,rr=4,mirrors=False)
        s.ramps['stripe']=R5(*stripe);s.height=H+6;s.H=H
    def matfn(s,pl,nl,nw,names,lam,info):
        x,y,z=pl[:,0],pl[:,1],pl[:,2];nx,ny,nz=nl[:,0],nl[:,1],nl[:,2]
        N=len(pl);m=np.array(['paint']*N,object);toff=np.zeros(N,int);isb=names=='body';side=np.abs(ny)>.55;fr=nx>.35;rear=nx<-.5;hw,hl,H=s.hw,s.hl,s.H
        m[isb&fr&(z>40)&(z<H-4)&(np.abs(y)<hw-2.2)&(nz<.9)]='glass'
        win=isb&side&(x>-hl+6)&(x<hl-10-(z-40)*0.25)&(z>46)&(z<H-8);m[win]='glass'
        for px in np.arange(-hl+24,hl-14,22):m[win&(np.abs(x-px)<1.2)]='trim'
        m[isb&side&(z>34)&(z<39)]='stripe'
        m[isb&rear&(z>44)&(z<H-8)&(np.abs(y)<hw-4)]='glass'
        m[isb&fr&(z>18)&(z<25)&(np.abs(y)>hw-8)]='lamp_f';m[isb&fr&(z>12)&(z<18)&(np.abs(y)<hw-8)]='trim'
        m[isb&rear&(z>16)&(z<30)&(np.abs(y)>hw-5)]='lamp_r';m[isb&(np.abs(x)>hl-6)&(z<11.5)&(z>3)]='bumper'
        m[isb&(np.abs(nx)>.45)&(z>6.5)&(z<10.5)&(np.abs(y)<5)]='plate';m[isb&(z<8.5)&side]='trim'
        g=m=='glass';u=x*info['xsign'];toff[g&side&(np.mod(u+z,26)<2.2)]=-3
        w=names=='wheel';wm=wheel_mat(pl,nl,s.wheels,s.R);m[w]=wm[w];return m,toff
def elf_travel():
    e=Elf(4.6,['#F4F1EA','#D9D3C7','#B8B2A6'],('#6FD18A','#3FB867','#2E9E52'));e.ramps['paint']=[hexrgb(h) for h in ['#FFFFFF','#F6F7F8','#E4E7EA','#C3C9D0','#97A0AB']];return e
class BusKota(Bus):
    def __init__(s):
        super().__init__()
        s.ramps['paint']=[hexrgb(h) for h in ['#7FB0F0','#4F8DE8','#3A73CF','#2C5BA8','#1E3F78']]
        s.ramps['white']=[hexrgb(h) for h in ['#FFFFFF','#FFFFFF','#F4F1EA','#D9D3C7','#A7B2C4']]
        s.ramps['ltblue']=R5('#FF8A8A','#E84545','#B82E33');s.rows=text_rows('bus kota')

def bus_kota():
    e=Elf(5.3,['#4F8DE8','#3A73CF','#2C5BA8'],('#FF8A8A','#E84545','#B82E33'),H=98);e.ramps['paint']=[hexrgb(h) for h in ['#7FB0F0','#4F8DE8','#3A73CF','#2C5BA8','#1E3F78']];return e
