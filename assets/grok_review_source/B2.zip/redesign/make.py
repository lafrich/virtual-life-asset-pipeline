import sys,json,hashlib,os
sys.path.insert(0,'.')
from car_defs import Van
from sdf import ramp5,hexrgb,sd_rbox,V
from grade import grade
from PIL import Image
P='/workspace/semesta-gallery-originals-public/assets/street_buildings/props/'
os.makedirs('out',exist_ok=True)
def angkot():
    v=Van(['#3FB867','#2E9E52','#227A3E']); v.ramps['stripe']=ramp5(grade('#F5E6A8'),grade('#EBD27A'),grade('#C9A94A'))
    orig=v.matfn
    def mf(pl,nl,nw,names,lam,info):
        m,t=orig(pl,nl,nw,names,lam,info); x,z=pl[:,0],pl[:,2]; side=(abs(nl[:,1])>0.55)&(names=='body')
        m[side&(x>-50)&(x<24)&(z>43)&(z<65)]='glass'
        for xs in (-26,-2): m[side&(abs(x-xs)<1.3)&(z>43)&(z<65)]='trim'
        return m,t
    v.matfn=mf; return v
def ambulans():
    v=Van(['#FBFBF8','#E4E6E8','#BFC4CA']); v.ramps['paint']=[hexrgb(h) for h in ['#FFFFFF','#F6F7F8','#E4E7EA','#C3C9D0','#97A0AB']]; v.ramps['stripe']=ramp5(grade('#FF6B6B'),grade('#E84545'),grade('#B82E33'))
    v.model.add('ac',lambda p: sd_rbox(p,V(30,0,75),(4,10,2.2),1.0))
    orig=v.matfn
    def mf(pl,nl,nw,names,lam,info):
        m,t=orig(pl,nl,nw,names,lam,info); y=pl[:,1]
        m[(names=='ac')&(y>0)]='lamp_r'; m[(names=='ac')&(y<=0)]='glass'; return m,t
    v.matfn=mf; return v
SPEC={'id200_transport_angkot_kota':angkot,'id200_transport_ambulans_puskesmas':ambulans}
man=[]
for vid,mk in SPEC.items():
    car=mk()
    for d in ['se','sw','ne','nw']:
        src=P+f'{vid}_{d}.png';O=Image.open(src);W,H=O.size
        cov=json.load(open('/workspace/semesta-gallery-public-b2/data/coverage-index-public-b2.json'))
        piv=[o for x in cov if x['id']==vid for o in x['originals'] if o['direction']==d][0]['pivot']
        img,tp=car.render(d)
        canvas=Image.new('RGBA',(W,H),(0,0,0,0));ox,oy=int(piv[0]-tp[0]),int(piv[1]-tp[1])
        canvas.alpha_composite(img.convert('RGBA'),(ox,oy)) if ox>=0 and oy>=0 and ox+img.width<=W and oy+img.height<=H else canvas.paste(img,(ox,oy),img)
        fn=f'out/{vid}_{d}.png';canvas.save(fn)
        man.append(dict(id=vid,dir=d,file=fn,size=[W,H],pivot=piv,templatePivot=list(map(int,tp)),templateSize=list(img.size),sha256=hashlib.sha256(open(fn,'rb').read()).hexdigest(),originalFile=src,originalSha256=hashlib.sha256(open(src,'rb').read()).hexdigest(),fits=ox>=0 and oy>=0 and ox+img.width<=W and oy+img.height<=H))
    print(vid,flush=True)
json.dump(man,open('redesign-manifest.json','w'),indent=1)
for m in man:print(m['id'][-12:],m['dir'],m['size'],m['templateSize'],m['fits'])
