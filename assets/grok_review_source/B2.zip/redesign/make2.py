import sys,json,hashlib,os;sys.path.insert(0,'.')
from b2defs import *
from PIL import Image
P='/workspace/semesta-gallery-originals-public/assets/street_buildings/props/'
cov={x['id']:x for x in json.load(open('/workspace/semesta-gallery-public-b2/data/coverage-index-public-b2.json'))}
SPEC={'id200_transport_pikap_sayur_keliling':pikap_sayur,'id200_transport_pikap_galon_isi_ulang':pikap_galon,'id200_transport_truk_pasir_proyek':truk_pasir,
 'id200_transport_truk_material_bangunan':truk_material,'id200_transport_mobil_angkut_sampah':angkut_sampah,'id200_transport_elf_travel_antarkota':elf_travel,'id200_transport_bus_kota_kecil':bus_kota}
only=sys.argv[1:] or list(SPEC)
man=json.load(open('b2-manifest.json')) if os.path.exists('b2-manifest.json') else []
man=[m for m in man if m['id'] not in only]
for vid in only:
    car=SPEC[vid]()
    for d in ['se','sw','ne','nw']:
        src=P+f'{vid}_{d}.png';O=Image.open(src);W,H=O.size
        piv=[o for o in cov[vid]['originals'] if o['direction']==d][0]['pivot']
        img,tp=car.render(d);img=img.convert('RGBA')
        cv=Image.new('RGBA',(W,H));ox,oy=int(piv[0]-tp[0]),int(piv[1]-tp[1]);cv.paste(img,(ox,oy),img)
        fits=sum(1 for a in img.getchannel('A').getdata() if a)==sum(1 for a in cv.getchannel('A').getdata() if a)
        fn=f'out/{vid}_{d}.png';cv.save(fn)
        man.append(dict(id=vid,dir=d,file=fn,size=[W,H],pivot=piv,templateSize=list(img.size),fits=fits,sha256=hashlib.sha256(open(fn,'rb').read()).hexdigest(),originalFile=src,originalSha256=hashlib.sha256(open(src,'rb').read()).hexdigest()))
    print(vid,[ (m['dir'],m['fits'],m['templateSize']) for m in man if m['id']==vid],flush=True)
json.dump(man,open('b2-manifest.json','w'),indent=1)
